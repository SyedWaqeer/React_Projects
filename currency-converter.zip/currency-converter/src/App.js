import './App.css';
import Login from './Components/Login';
import CurrencyConverter from './Components/CurrencyConverter';

function App() {
  return (

      <CurrencyConverter />
 
  );
}

export default App;
