import React, { useState, useEffect } from 'react';
import axios from 'axios';

function CurrencyConverter() {
  const [amount, setAmount] = useState('');
  const [fromCurrency, setFromCurrency] = useState('usd');
  const [toCurrency, setToCurrency] = useState('inr');
  const [currencies, setCurrencies] = useState([]);
  const [convertedAmount, setConvertedAmount] = useState(null);
  useEffect(() => {
    axios.get('https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies.json')
      .then(response => {
        const availableCurrencies = Object.keys(response.data);
        setCurrencies(availableCurrencies);
      })
      .catch(error => {
        console.error('Error fetching available currencies:', error);
      });
  }, [fromCurrency]);


  const calculateResult = async () => {
    try {
      const response = await fetch(
        `https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/${fromCurrency}.json`
      );
      const data = await response.json();
 
      const u = Object.values(data);
      const conversionRate = u[1][toCurrency];
      if (!conversionRate) {
        console.error('Conversion rate not available for selected currencies');
        return;
      }
 
      const convertedValue = amount * conversionRate;
      setConvertedAmount(convertedValue.toFixed(2));
    } catch (error) {
      console.error('Error fetching conversion rates:', error);
    }
  };

  const handleSwap = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };

  return (
    
    <div className="flex items-center justify-center">
      <div className="max-w-screen-lg">
        <h1 className="text-center mr-10 p-12 mb-4 text-4xl font-bold ">Currency Converter</h1>
        <label className="block mb-2">
          Amount:
          <input
            type="number"
            className="form-input w-full  border rounded p-2 h-10"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </label>
        <div className="flex items-center space-x-4">
          <label className="flex-1">
            From Currency:
            <select
              className="border rounded p-2 w-full"
              value={fromCurrency}
              onChange={(e) => setFromCurrency(e.target.value)}
            >
              {currencies.map((currency) => (
                <option key={currency} value={currency}>
                  {currency}
                </option>
              ))}
            </select>
          </label>
          <div onClick={handleSwap} className="cursor-pointer" style={{ fontSize: '1.5em', padding: '0.5em', paddingTop: '1.2em', display: 'block' }}>
            ↔️
          </div>
          <label className="flex-1">
            To Currency:
            <select
              className="border rounded p-2 w-full"
              value={toCurrency}
              onChange={(e) => setToCurrency(e.target.value)}
            >
              {currencies.map((currency) => (
                <option
                className="bg-gray-200 text-gray-800"
                 key={currency} 
                 value={currency}
                 >
                  {currency}
                </option>
              ))}
            </select>
          </label>
        </div>
        <button
          className="bg-blue-500 text-white w-full  rounded-md mt-4 h-10"
         onClick={calculateResult}
        >
          Calculate
        </button>
        <p className="text-center mt-3 text-lg">
          {convertedAmount && `Result: ${convertedAmount} ${toCurrency}`}
        </p>
      </div>
    </div>
              
  )
}

export default CurrencyConverter;
