import { BrowserRouter } from 'react-router-dom';
import Footer from './components/Footer';
import Header from './components/Header';
import RouteList from './routes/Routelist';
import { Suspense } from 'react';
import { ProductProvider } from '../src/data/ProductContext';
import { AuthProvider } from './data/AuthContext';
import { CartProvider } from './data/CartContext';


function App() {
  return (
    <BrowserRouter>
      <ProductProvider>
        <CartProvider>
          <AuthProvider>
            <Header />
            <Suspense fallback={<div>Loading...</div>}>
              <RouteList />
            </Suspense>
            <Footer />
          </AuthProvider>
        </CartProvider>
      </ProductProvider>
    </BrowserRouter>
  );
}

export default App;


