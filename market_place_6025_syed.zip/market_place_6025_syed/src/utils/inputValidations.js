
export const name_validation = {
    name: 'username',
    label: 'Name',
    type: 'text',
    id: 'names',
    validation: {
      required: {
        value: true,
        message: 'Name is required',
      },
      maxLength: {
        value: 30,
        message: '30 characters max',
      },
    },
  }
  
  
  
  export const password_validation = {
    name: 'password',
    label: 'Password',
    type: 'password',
    id: 'password',
    validation: {
      required: {
        value: true,
        message: 'Password is required',
      },
      minLength: {
        value: 6,
        message: 'min 6 characters',
      },
    },
  }
  
  export const num_validation = {
    name: 'num',
    label: 'Phone_Number',
    type: 'number',
    id: 'num',
    validation: {
      required: {
        value: true,
        message: 'Phone Number is required',
      },
    },
  }
  
  export const email_validation = {
    name: 'email',
    label: 'Email',
    type: 'email',
    id: 'email',
    validation: {
      required: {
        value: true,
        message: 'email address is required',
      },
      pattern: {
        value:
          /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
        message: 'not valid',
      },
    },
  }
  
  
  