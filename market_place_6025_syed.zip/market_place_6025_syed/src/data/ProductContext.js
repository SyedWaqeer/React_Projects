import React, { createContext, useContext, useState } from 'react';

const ProductContext = createContext();

export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([

    {
        id: 1,
        imageSrc: 'https://tailwindui.com/img/ecommerce-images/product-page-01-related-product-01.jpg',
        name: 'Basic Tee 6-Pack',
        price: '$192',
        color: 'black',
        href: '#',
        breadcrumbs: [
          { id: 1, name: 'Men', href: '#' },
          { id: 2, name: 'Clothing', href: '#' },
        ],
        images: [
          {
            src: 'https://tailwindui.com/img/ecommerce-images/product-page-02-secondary-product-shot.jpg',
            alt: 'Two each of gray, white, and black shirts laying flat.',
          },
          {
            src: 'https://tailwindui.com/img/ecommerce-images/product-page-02-tertiary-product-shot-01.jpg',
            alt: 'Model wearing plain black basic tee.',
          },
          {
            src: 'https://tailwindui.com/img/ecommerce-images/product-page-02-tertiary-product-shot-02.jpg',
            alt: 'Model wearing plain gray basic tee.',
          },
          {
            src: 'https://tailwindui.com/img/ecommerce-images/product-page-02-featured-product-shot.jpg',
            alt: 'Model wearing plain white basic tee.',
          },
        ],
        colors: [
          { name: 'White', class: 'bg-white', selectedClass: 'ring-gray-400' },
          { name: 'Gray', class: 'bg-gray-200', selectedClass: 'ring-gray-400' },
          { name: 'Black', class: 'bg-gray-900', selectedClass: 'ring-gray-900' },
        ],
        sizes: [
          { name: 'XXS', inStock: false },
          { name: 'XS', inStock: true },
          { name: 'S', inStock: true },
          { name: 'M', inStock: true },
          { name: 'L', inStock: true },
          { name: 'XL', inStock: true },
          { name: '2XL', inStock: true },
          { name: '3XL', inStock: true },
        ],
        description:
          'The Basic Tee 6-Pack allows you to fully express your vibrant personality with three grayscale options. Feeling adventurous? Put on a heather gray tee. Want to be a trendsetter? Try our exclusive colorway: "Black". Need to add an extra pop of color to your outfit? Our white tee has you covered.',
        highlights: [
          'Hand cut and sewn locally',
          'Dyed with our proprietary colors',
          'Pre-washed & pre-shrunk',
          'Ultra-soft 100% cotton',
        ],
        details:
          'The 6-Pack includes two black, two white, and two heather gray Basic Tees. Sign up for our subscription service and be the first to get new, exciting colors, like our upcoming "Charcoal Gray" limited release.',
      },

      {
        id: 2,
        imageSrc: 'https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/9793513/2022/4/18/80ba23a6-226f-4f43-bb1a-a2a7d57ddcd71650284941307RoadsterMenWhitePureCottonT-shirt1.jpg',
        name: 'White Tshirt',
        price: '$220',
        color: 'white',
        href: '#',
        breadcrumbs: [
          { id: 3, name: 'Men', href: '#' },
          { id: 4, name: 'Outerwear', href: '#' },
        ],
        images: [
          {
            src: 'https://thehouseofrare.com/cdn/shop/products/IMG_0204_4b3b8189-e099-42ba-be1a-0a8b88c80c2d.jpg?v=1664363280',
            alt: 'Front view of a premium black hoodie.',
          },
          {
            src: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8QDw8PDw8PDw8NDw8PDw8NDw8PDw8PFRUWFhURFRUYHSggGBolGxUVITEhJSkrLi8uFx8zODMsNygtLisBCgoKDg0OGhAQFy0dHyAtLSsrKy0tLSstLS0tLS0tLS0tLS0tLS0tLS0tLSstLS0tLS0tLS0tLS0tLSstLS0tN//AABEIAOEA4QMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAABAgADBAUGBwj/xABFEAACAQIDBAcFBAULBQEAAAAAAQIDEQQSIQUxQVEGBxNhcYGRIlKhscEyQmJyc4KSorMjJTQ1U3SywtHw8RVEo8PhFP/EABkBAQADAQEAAAAAAAAAAAAAAAABAgMEBf/EACMRAQACAgIDAAIDAQAAAAAAAAABAgMRITEEEkFCYSIycRP/2gAMAwEAAhEDEQA/APRGALAzldIACwAREIQCEIACEIQBK1SMYuU5RjGKcpSk1GMUt7be5HnPSLrOhGTpYCCqOLadeqm6TtxhFO8l3uy8TF66MbUzYXDKUlSlCdacU/ZqSzJRvzy2f7R53hKMpaKLlJ/ZSTbb7rGlaxrcs5tO9Q6qXTran2nira3tGjh8q7rZG7eZudgdZtRSUMdGEoy+zWoxyu3em7Px0OZpdGcc1d0KkNPvRsajaey61GyqU5rfvi0vJk/xngmLRy+hsBjqVenGrRnCpCW6UJRkr8rp7y9ni/VRtOdLHxoOTVPFRnHJ93tIpzi7cNFJX70e0sztGpWrO4AhCELAwBAAGKMwAAhCAKxWOxWArAwgYAIQgG0YoWK2BCEFbAYgtwXAYgLkuASAuQDhesXZkauJ2bOavHNXpyXPSMop+jN7gKFK0LU4rItGorTwLulGCVXDSkrKph716Un92cYyTduPsykrd5yextuV41KVOSdWlVlGPaOCpyi5NpaLevRlbxMw0xTES79VYxheTjGPFyaS+JwfTfYk8V7dGcW0m1B7pfllu9TP2vs3ESq9pT7OVn7DnT7RQd1vu1wvuNlhsHOML1MjlxcIZE/FXZlvWphvNd8TDybophJ/9Qw8owkpUa0alS33IQku0v5XVuN7Hu177tz3NcUcnsLZyo1MZKDiu0qqprFNuMotuD7rqT8zp8KrU4rklv5cDb/p7S55xekbWEIQlQCMIAAxWMKwAQhAAxWMxWAoGFgYAIQgGykK2STEbALYLgA2ASC3BcByCXDcBrhuLcgErU88ZR4TjKPqrHD9vShKiptU8s1nctMsocH52O6RwnTfZMu2jVVuzqt/aV4qtbdJcb2uu+5GtrUtp0FLadNyko1IpJvWV4xdvdb+1v4XMiWNjOmrNbnqmnc57YtLtLxnGolFK7cadKD03LLZteJKu1cNSzU4K1m1GMdfaurW57zGa/Idc20ytjOTxk4uTUcmsUlaV02rvuy8ObOrscfs9TpNYmUXmlKMnDiqaTTXjZs66lVjOKlBqUZK6aNKTDmyRP0WAYUuzQASAKwWCwMAACAAMDCABGALAACEIBmyYGRithCNitgbEcgk9wXK8wLgW3DcpuFSAuTGTKVIdMC1FG0MFCvSnRqK8Kis7aNNaqUXwaaTT7i1MZAee7Y2fj8K40+2p1KdbPGE/apy4faVtHrz4F2wdhRpSVSq1UrPjb2YeC+p1m3tnyxFKMYRcpwqRnFR38U/g7+Quz+j+MlOOamoRj96copeiu/gUvFp4rDTHNY5tJa1JNeC18Dc9GujvZuVapmSmvZo3ajb35rnyNps/Y0KTUpvtKi3aezF9y595s2aYfH9Z9rKZs/tHrVqsVsrjTdvwt/U1lWlKLtJNeJ01gVKEZK0kmuRvbFE9MIvMOWIbLaGzsl5Qu48U967/A1rMJrMcS1idgwBAQkrAMxQAAIAEYBmKBCEIBkyYrYZCMANiMMmIwIC4GwANciYhLgWpjRZSmNFgZCZfSpt+CMekrtLm0jdRppJJbi1Y2radL8Bh4xWZb2uJnRbKqaskXU0dVY1DA6AENiwCQxAIgCcbqxzOLoOE3HzXhwOnNNtyP2H3yXy/wDplljja9J5aoUYU52xZAYWBgBihYrADAEAEIQgGRIRjzEZASQjGYjAVgIxGwC2BsW5LgMmWQZSmPGQ2M/AP+Uh4m9o09TmqM7Si+TTOpwi0vzNcXLLIyCyBUyym9DphktRCAzBJZSa0+JIyErO8ZW3pNpa7wYaalFNbmk/J7gheYG2Kd6bfutP6fUzyrFQzQkucWiLRuNJjiXLCsZis43SVgCwABisZisBQBABCEIBkyK2WSEaIFTEkWSK5ECuTK2PIRgKwBYpIZMZMrCmBkQZ1mEqXimtxyEWdJseVqSvxka4+2eTpsU7l1NFUS6B0QxHjy5Eyy7h2roEXwJSMXLijEwSs5w9yckvB+0vg7eRm3OK6ZYurSrxjCpKEKsE5KDy5mnbVrXkUvb1ja1a+06ddXxlKnpOpCL5NrN6bzUbS6V4alFu1SpbhCNvjJo5KhMwtqu8WcdvKt8h2V8Wv2XUKeZKS0UlmS7nqBlOz5Xo0XzpU3+6i1lmRWAIGALithYoEAQgEIAgGVLiIx5cSuRUJIrkx5MrkBXIrbHkVyAVsVsjFANyJikJF8GbLoptyni1KMYuDouN4tp5o6pST8maatUywnL3YSl6Jsw+rKcViKsdMzoq3gnr8XEvSeVbRxt6cuBdApXAuidUOc6CBBLJA47rDp2WHqfilBvxV18Y28zsjTdK8AsRhK0OOVyj3SSuilo3GlqzqduEwdW9inaD3oqwCaa70n58fjcm16lpJcWnfwPLvXU6epS0Wrt0mx5Xw1H9HFeit9DKZruj1TNhaT5Z4+kpI2DOiHHPYCsYDJQVijMUCACACEAQDKkVssfERlRVJFci2RXJAUyK5FsiqROhWxBpCNgRslxWwXJGNtmvkoVPxrIv1tH8L+hg9XClLaDaWkKNRyfCzsl8Snb9bNJQW6mrv8z3ei+ZuerKkoqvVtvrQpt/ljmt/wCQV/sm0apt6VHe/AtiU0y6J2Vch4jCIa5ZImNjXanP8svkzIZpeleL7LDVGt8lkXiytp1CYjbgqCvUk1uTdjCre1UqSfKy7jLwa9lmNKGepGn/AGk1DTk2k2eVM+1nq11Wv+Ol2LSyYelHnHP+23L6mWwtW0WiWiFZ0OKeUbFbIxSQWxSMABYGwMVgNmIIQDPkVstkVyIFciqRbIrkBTIqkXSKZEiqRXJlkiqQCkRCrETywlL3YtrxtoQNDWebtanvTlbwTsvhY6vq2UXg6vF//rqZvwvJTsvSxzNalkw9u46rqvssG7rSrWrS8Wmo/wCX4DDzK+fisQ7bDSurckjJizFoJIyUdlenHJ0xrFTGi2XQdHI9YVT+Spw96aOtOJ6dVc1ahTW+Kzvuu7L5MyzTqktcMbvDn8NdJ+YdiU8+KzcKMJS/Wl7K+DfoNWeWD7zO6NYbLSlUa1ryzfqLSP1fmefjjnbvy21Gm2YoWC5u5SsUZsVsAMBANgS4rZAMgC4RQgbGRXIskVyJFcytlkiqRArkUzLZFUgKZCMeRXIkKzFxqbywX35K/gtfnYymU0YZqzfCnBeru/lYradQvjjdoa/pC1Ck1yR03QWhKGzcM2mpPtZ2e/2qs5J+jRzOOpdvWjTf2FadT8q3R8/9T0bZVNqjTVlbJF+q1LYY4V8iedNhQkmk+aMhGFSpSg1uyt8zOin/ALZ1VcsiQji+QUpci+0DfS74HmuOxHb4irV3pyaj3RWi/wBTsulePdDDSa0lVfZx53lva8rnE4WKSVuWhyeVfqrs8WndlVWg6k4Uk37bs3ygtZPyVzpoxSSilZRSSS4JaJGr2FjMIqtenKvSeMcclPDqV6kadlKcmluveO/3e82rZnWuoj9pyW9rT+isRjMrbJURgI2BgBgbIACAYQMgKEFyEjYyEkPIrYCTKpMsmVSAqmVTZZIqkQK5MrkNIrkAGyjC37KpLe5OUtOX/BMXNqNlvm1Fee/4XL8I4xTp8Ute65WzbFHcsXAUcsbv7dR5pP5R8lp6nA7d6e7TWIrUqOMnCjRqzp0owp0FaMXltfJd7uLPQ8NK6j6LwTsjw3FVXKpUnbWdSc3bVXlJvT1OjDHblyujp9Ye2Y7toVf1oUJfOBkx6ztuL/v/AFw2Df8A6zjXMimdDF3lLrb23HfiKM/zYWl/lsZNPrj2wt7wkvHDP6TPPFK5m7FwvbYilTtmUpLMuGVc+69l5kTOuUxG509Z2dt/G4+lTq4103meanClT7OMIPRN6ttta7+RtoUreXMpwtNRjZJWTSS7kkZCqd2trHnWn2tuXqVr6V1Dy/Yu0uz24q9RvXGVqM3a7tLPRjpyV4+h7YzwnYMI4ja9NSdoVcdOqmvwzlVivPKl5nujZ1Zfjhp9STK2MxWzJcANgbAxsEBAECEbIxWiRCACBsJFbZZLiVSICSKZstkyiYFcmVSLJlUgEkVSHkVyYGNCT7e0o3jkvB9/3vPcaPZ2PnUxGIbisqSpxcdc2jd974M3uIclllFXcHe3Fx4pd+70Odwinh8VWyRhOni4xcakk1aSupaLdK7f+0NN8c8Rp0VeWSjNx+5Sk4+UdPkeF09y8Ee44yzoVVwdGotPys8OhuWnBHRh+uPJ2LtxsVSVt24uFkjZkSLOr6LSw6lShSdSWImnOvKUcsKaje0Ic9XHXj3bjklvMvZ2NlQqKpG90mtOT/4RS8bjS+O3rbb1WntOpHM76KXZ3evtZsqt56FeO2vOMMTrZ4eg5vvk4Skv8K9TiJdKWqNOEYZpqcZzcnZNpuT9ZM1+N2zVrObkox7WyllvrFWtHXwMYwzvl1W8iNcMrofSzbQwMFLJbE0pZvyPNl88uXzPf7ngfQrDxqbSwcJq8e2zWTa1hGU46+MUe9Nk5u4YY+gbFYQGLQCBaABABIABGOIyYEIQhIzpMrkxpFcioSTKZMskVSArkyqTLJFUgK5FcmPIrkAhRXwkZdz13WabfFriXkCYmY6VVKS7KUFu7OUV5pnhtPcvBHvMTwqtSyTnT/s5zh+y2vob4frHIUVoYDN2SiZdWoyhOVOcXGdOThOL3xknZoz+jeD7fHYSk0mp16eZPjCLzS/dTNt1k4Tstp1nwxEaddeayy/ehIrvnSdcbcykMhUEsh0PQF/zpg/0k/4Uz3Q8I6DP+c8F+mt6wkj3ixz5u4bY+gIQjRi0AAWACAIQAMVjCskAgCAZ0iqRCECtlTCQCqRVMhAKpFUyEArCEgEPE9rf0rE/3mv/ABJEIbYe5ZZGKRgIdDJvur7+tMJ41v4NQ3PW9/S8N/dn/EkEhl+a/wCLhUEhDVRvug/9Z4L9Ov8ADI95YSHPm7hrj6AUJDKGpWAhBIDAyEEBSEIApCEIH//Z',
            alt: 'Model wearing the premium hoodie with a cap.',
          },
          {
            src: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8PDQ8NDw0NDQ8NDw8QDQ0NDQ8NDQ0PFREWFhURFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDQ0NDg0NDjcZFRkrNzc3KysrKys3KysrLSsrKzctKysrKysrNysrKysrKysrKysrKysrKysrKysrKysrK//AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQYCBAcFA//EAEQQAAIBAQIHDAcHAQkAAAAAAAABAgMEEQUGEiExQVEHExQyU2FxcoGSsdEiIzRCc5HBJDNSYmOywkMWRFSCg5Oh0uH/xAAWAQEBAQAAAAAAAAAAAAAAAAAAAQL/xAAWEQEBAQAAAAAAAAAAAAAAAAAAEQH/2gAMAwEAAhEDEQA/ANYAEaAAAAAAAAAD0cGYEtFofq6byddSXowXbrA84F8wdiXRhc603WlrjH0YL6s9W14t2SpBR3mMLlmlSWRNduvtKlcuBea2Icb/AELTJLZKmpeDR8v7BP8AxS/2X/2IKWC8wxCh71pm+iml4s3bPiXZIZ5b7V60rl8kCucg6tVwBZJw3t2enFXZnFZMum/SVrCeI8lfKz1FP9Opml2PQCqcDYtliq0ZZNWnKm/zLM+h6zXCgAAAAAAAAAAAAAAAAAAAHp4BwRO11VBXqEbnUnqivMI0aFnnUlk04Tm9kYuTPfwfidaKlzqyjQjsfpT+S0F8sFhp0IKnThGMUtmeXO3rNlIpXhYOxYstG573vsvx1fS+UdB7apq67RdqWZIzARCRE4XrNemthkAPhlP8XzV4nVktGfszGc4a0fGpSjLSnm2SkvAuDJ13sbebUTJt5sp9lxhSpRjfkp59snLxPtTjtGjJRS7NLvIbMpbA0QfG0U6dSLhUhGonqkkyuYQxNs9S+VJzoS2ceHyedFpyUjGU9gHMcI4s2qhe8jfYr3qfpZudaTx2rszV3SdljDS2eHhnAtG1JtQUJ+7Vis7fPtQWuag2sIWGpZ6jp1ItNaHqktqNUgAAKAAAAAAAAAH2slmnVqRpU4uUpO5JAfbBeDqlpqqlTWd8aWqK2s6hgrB1OzUo0qa0caWuctrNfAWCIWSkoK5zlc6k7s8ns6D1EVlL1Mkh6GRfnAyIuJABEkC8CUQ0thDZjkgZZuYjNqIuJALWL7kABjImMbiVElZ30AfG3Tyady0yaiul5iIQuSWxGNtz1KUdV8pPsX/p9WB52GsFU7VSyJq6S4k0s8X5HNsJ4PqWao6VRXP3XqktqOtM0MMYLp2qm4TVzXEmuNF+QHKQbmFMHVLNUdOourL3ZLajTIoAAoAAABMU27kr29CWsBCLk1FJtt3JLO2zo2KuA1ZqeXNeuqLPryI/hRq4qYu7ylaK0fWPiQf9NbektCZUSjJIwTM0EZIxRkYJgZBBEgCCReBFxIAAi4kgAAAIMoIhEgatf7+HUn4o+pjVXrKb6y+av+hntAxZDJIA0cLYNp2mnvc1n92WuL2o5vhXBlSzVHTqLqy92S2o6qjUwtg6naKThUXVl70XtQHKAb2FcGVLNUyJq9PPCeqSNEigACheMUcAxjCFqqXTlNZVOOlQT19JRywYs4wuzyVKo3KhJ9LpvauYqOhkmNOalFSi1KMkmms6aMkESjJGJkgMtR84szbzGCQH0QIQvAkIACQQSAIAAAEMAZIgAfK0an+Fp9l+cnzMqiyotbUfKnK9X69YGTIJIAB+IuPnXqxhFyk1GMVe5PYB52MlOi7LU3266MXkPWp3Zru05iezjJht2qpdG+NKD9Ffie1njBcAARQAAWLFfGF2eSpVW3Rk+l03t6DoUJKSUotNNXprOmjjZacUsYd5as9Z+rk/Qm/6b2dBUXwlBZ86z/UJBGTRi0ZN3GMpADIxiZASgEAF4BAEgEASCAwBJBFwEnzhG5tbc59D4zb3yN2jJlf80BlzEEvSAIbu5ks7b1IoONmHt/lvFJ+qg/SfKPyN3G/GDTZaLzaKs1r/ACopoUABFAAAAAAAAWzFXGbekrPaJehop1H7nM+Y93CWNlmopqElXlqVN3x7Wc2ASOn4s4Zdsp1JSgoOnPJui2001etJ6zKluefdV+vD9rLayolGRijICQAAAAAAgAAGBADIQEs8TGy2VKFm3ylLInlJKWZ5m8+k9srWPr+ypfnj4geLYMdK8c1aEay2r0J/8ZjdwrjhTlQcaCmqs1c3JJZC1u8pQIsS3e73pekgAKAAAAAAAAAAAAALxudr1Vo68P2stusqe5591X+JD9pbSspSJCJAAAAAADIAAEMkAQAQBmVfH32X/PHxLOVjH1fZV14+IHPgARoAAAAAAAAAAAAAAABd9zv7u0deHgy4FP3OuJaOtT8GXDWVNZBEEhAAAAwAIBIAgEkAQESQgJRWcffZF8SBZkVnH32RL9SP1A56ACNAAAAAAAAAAAAAAAALvudcS0dan4SLgU7c54tp61LwkXLWVNSAAgwAABJDAAAAAAMUGEAJKzj97KviRLOisY/eyr4kQOegAjQAAAAAAAAAAAAAAAC77nPEtPWp+Ei4lO3OeJaOtT8JFyKmgCARIAAAACASQAIJAEAEgCsY/eyr4kfqWdFYx+9lXxI/UDnoAI0AAAAAAAAAAAAAAAAvG5xxbT1qfhIuLKZucaLT00v5F0KmgACAAAAAAAABFxIAgAIAVjH5/ZUvzxLQVjH9fZIv9SK8QOeAAjQAAAAAAAAAAAAAAAC67nH95/0v5F1KXucaLT00v5F0KmhJBIRBJBIAEACQCAAAAMhC8kAVnH/2OPxYeDLMVndA9jj8WHgwOdgAjQAAAAAAAAAAAAAAAC5bnNWKnXg2lKSpuKbzu7Kvu+ZebuZnFU2nend0Zj6cIqcpU78vMqOzXczF3McZ4TU5Sp35eYVpqL+rU78vMlI7NcMnmONStdV6atV9NST+pHCKnKVO/LzFI7Nk8wyeY4zwipylTvy8xwmpylTvy8xSOzXcwceZnGeE1OUqd+XmOE1OUqd+XmKR2bJ5mMnmOM8JqcpU78vMcIqcpU78vMUjsriSo8xxnhNTlKnfkOE1OUqd+XmKR2VrmKxugzXA4LW6sbl0J3lB4TU5Sp35eZhOpKXGlKXWbZaRiACKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/9k=',
            alt: 'Model wearing the premium hoodie with a backpack.',
          },
          {
            src: 'https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/9793513/2022/4/18/80ba23a6-226f-4f43-bb1a-a2a7d57ddcd71650284941307RoadsterMenWhitePureCottonT-shirt1.jpg',
            alt: 'Close-up of the premium hoodie fabric texture.',
          },
        ],
        colors: [
          { name: 'Black', class: 'bg-black', selectedClass: 'ring-gray-700' },
          { name: 'Charcoal', class: 'bg-gray-800', selectedClass: 'ring-gray-800' },
          { name: 'Navy', class: 'bg-blue-800', selectedClass: 'ring-blue-800' },
        ],
        sizes: [
          { name: 'XS', inStock: true },
          { name: 'S', inStock: true },
          { name: 'M', inStock: true },
          { name: 'L', inStock: true },
          { name: 'XL', inStock: true },
        ],
        description:
          'Stay warm and stylish with our Premium White Tshirt. Made from high-quality materials, this Tshirt is perfect for any casual occasion. Choose from classic black, charcoal gray, or navy blue to suit your style.',
        highlights: [
          'Premium quality fabric',
          'Versatile and comfortable fit',
          'Ideal for layering',
          'Available in multiple colors',
        ],
        details:
          'The Premium Tshirt is a must-have for your wardrobe. Whether you\'re heading out for a run or just lounging at home, this hoodie will keep you comfortable and looking great.',
      },
      {
        id: 3,
        imageSrc: 'https://media.gettyimages.com/id/109433981/photo/boy-wearing-orange-t-shirt-playing-with-toy-plane.jpg?s=612x612&w=0&k=20&c=hOKHrutzEgEAiSKo8PAg8X5ZSnEYzzk1Kzewz_aWbr0=',
        name: 'Orange Tshirt',
        price: '$500',
        color: 'orange',
        href: '#',
        breadcrumbs: [
          { id: 3, name: 'Men', href: '#' },
          { id: 4, name: 'Outerwear', href: '#' },
        ],
        images: [
          {
            src: 'https://muselot.in/cdn/shop/products/3_f0aee5ac-6678-4613-8f02-c5d5820dd010.jpg?v=1625002577&width=1445',
            alt: 'Front view of a premium black hoodie.',
          },
          {
            src: 'https://media.gettyimages.com/id/109433981/photo/boy-wearing-orange-t-shirt-playing-with-toy-plane.jpg?s=612x612&w=0&k=20&c=hOKHrutzEgEAiSKo8PAg8X5ZSnEYzzk1Kzewz_aWbr0=',
            alt: 'Model wearing the premium hoodie with a cap.',
          },
          {
            src: 'https://media.gettyimages.com/id/109433981/photo/boy-wearing-orange-t-shirt-playing-with-toy-plane.jpg?s=612x612&w=0&k=20&c=hOKHrutzEgEAiSKo8PAg8X5ZSnEYzzk1Kzewz_aWbr0=',
            alt: 'Model wearing the premium hoodie with a backpack.',
          },
          {
            src: 'https://5.imimg.com/data5/SELLER/Default/2021/5/ES/XP/FW/125037753/orange-t-shirt.jpg',
            alt: 'Close-up of the premium hoodie fabric texture.',
          },
        ],
        colors: [
          { name: 'Orange', class: 'bg-orange-600', selectedClass: 'ring-orange-800' },
        ],
        sizes: [
          { name: 'XS', inStock: true },
          { name: 'S', inStock: true },
          { name: 'M', inStock: true },
          { name: 'L', inStock: true },
          { name: 'XL', inStock: true },
        ],
        description:
          'Stay warm and stylish with our Orange Tshirt. Made from high-quality materials, this hoodie is perfect for any casual occasion. Choose from classic black, charcoal gray, or navy blue to suit your style.',
        highlights: [
          'Premium quality fabric',
          'Versatile and comfortable fit',
          'Ideal for layering',
          'Available in multiple colors',
        ],
        details:
          'The Premium Orange Tshirt is a must-have for your wardrobe. Whether you\'re heading out for a run or just lounging at home, this Orange Tshirt will keep you comfortable and looking great.',
      },
      {
        id: 4,
        imageSrc: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUREhISEhEREhEREhERERERERERERERGBgZGRgYGBgcIS4lHB4rIRgZJjgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHhISGjEhJCQ0NDQ0NjE0NDE0NDE0MTQ0NDQ0NDE0NDQ0NDExNDQ0NDQxNDQ0MTQ0NDQxPTQ0NDQ0Mf/AABEIAPsAyAMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAAAQIFAwQGBwj/xABCEAACAQIDBAcEBggFBQAAAAABAgADEQQSIQUxQVEGEyJhcYGRMqGxwSNCUmJy0QcUJDNTgsLwNEOSsuEVc3Si0v/EABkBAQADAQEAAAAAAAAAAAAAAAABAgMEBf/EAB8RAQACAwEAAwEBAAAAAAAAAAABAgMRITESMkEiFP/aAAwDAQACEQMRAD8A7GEIpYEcIQCEIQg5q4/aFPDp1lV1ppewJ3k8gBqT3CZcTiEpo1So6pTQXZ2NlUTyjbm0Tjq71czfq6HLRVrqAg45eZ3nju5SszpasbXeP6aVapdMOqUqe4VHOatb7WXcPfKStjarD6TEVKi33s7kA94ubek0lrhRYKrDd7TK3xtIDErwLXGhRzdh4GZzMy0iIhY4Ta74Z81NyM2hBN0qd3j42M7vo90mp4tVUkJW3MhNgT93xGtu4zyHGVSTYa9/np/fjMFKuyMrBrMpDKRvDcDLV4raYl9Cwlb0e2oMXh6dYaEjK63vlddGHz85ZTRQQhCEHCKEAgRCEBESJk4jAxkSJEmZEwImECIQM0cIQkQhCAQhCBxv6RcQ3V0aIHYqO1So33Uy2HmW904DEvlAUA6DhoPQTvOn9B6j4UItwS65j7IdimUE8L/Kc/0a6PfrFep1wISi2Wom4l/sn0mVp12WlY3yFNs7Y9bFH6KmTY2L6KB58Z0GH6BYhnBqMgFhchiZ6hgMElJAqKFUDQKLCSqLrpMpvLaKQ852l0N6lDUWxtYW+M4zEbJdTu1v6z3TE0c6lWGhnK7Y2UqDPvW9mBA0vukxZFqRLR/Ri5VMRSOlmSoB3sCp/wBqzupyWwcA1B2rr2g9PKKY0JXMCWJ5iwt+Izq0YEAjcQCPAzatoljak17KUIQl2YhCEAhFCA4jCECJkTJyJgQMIyIQMsIQhIjhCAoRwgQdAwswBB4ESuGEShUrVswVKvVs+YgBaiggtfvFvMGWk1do4RKyFKihluGAYXFxqLjjKWruq9Lats8BtjDv2UrJUYcEYGU3Szb9akMmHQLcXaq3aynkq8T46SvwnRx1qrUD9WQxJFMKqEX04ct/ynV4jCI6qWAuLHcN4nPzfHTEb9cTs2piHcK/62zqRmZ6hVCTyUMAfQzs+qvTy1NQRYg6zNQwqL2lAvz3mY8Q/CRM7TEahUU0cdT1bkCmz03Qi6MgJsTyNh75d0FsoA3AWHhwlNgFzvruFRiedmAtr5GXoFprir2ZZZrbiIEIQm7mEUdooBCEIBFHFCRFHFCCIhHCEpRwhAIQhAIQhAIQhA19xI9PCaG1tsrh16sAF7aZibdx0m9jUNg66su9RvZOIHeN49OMoHwpdmcuhtrmCB3C7xYNoPQzmtX42dmO3yjX62sJtlVp3qEhmJbQEIoPCZ8ZiPo7g+0ND/xKvBlKhYFHfIbs1Y5jccbHQeQErtpbUZcyncXso5cgJTXVrTELLZFe9VgDupqfMMSJ1QN5yXR6h1a5mFnfVuNhwHwld0m25jsLiUp0mTqa2UU2NJXKtuZSTy9rw8JtS3dOe8fzt30JW7F2j19PtfvEsH4X5N5/EGWU2YR0QheEJKEcRhAijihIiheKECEV4QMsIQhIhCEAhCOAoQg7AAkkAAXJOgA5kwCc3tzD9TVp1qV81UsHpj65AvmUc+7jw13y2l0nRLrRXrG3ZyDkB7vte6cvicbVrNeo7k3uljYJxBUDRTcDXuia/KNIi/xncNjFbXYZ+y5uNbU2Av3m2+amApGo2d/qfu0OuXvPfLnAbVWugSqVDgtTz2+jqFdD4NpqPSb36mEDObBFBY23ZQLkzmncc06omLRvaOCfIt2IAA1MqNqY7rmFh2V9m41PfKqtt81KnVsopow7ABJ1vuc85lL218vE902x49dlz5cu/wCY8WOzdoNh3zque4yst7Aqbce6wnT4XpBTfRw1M/eGZf8AUPmJx2GoEEs3tMAD3AXsPfNm2k3mu3PFph3tN1cZlZWU7ipBHrJThsNXembo5U93HxG4y+we3QdKq5T9tNV8xvHleUmstIvEruKRRwwDKQVOoINwZKQsURjihJRQMUAhFCEM8I4oSIQjgEITDjMQKVN6h3IpNuZ4DzNh5wNTau1kwy9rtVGF0pg6nvJ4DvnH4/aNTEH6Ruxe4RdKY8uJ7zMNd2qOzuczsbk/3wkGWXiumNrbYzIVAbXG8XtM2WMLLKqXBUK/UmjUbsBmdR9YOxuWvw1F5bNtlxhGwxR3quMgOlurPtG/hcecy2k0pUjTYlX68sMrBrJ1dt3O9/lrvBzmkTpeuS0bVeC2Rft1NWPAblHKW1Ogq20vbcTqZNBYW4CSmkQpM7ShEIxCBMYqb+4284V6gRWb7Kk+gvK7C1LIlzqwLufu3v7z8IIdFsnaDU3UZvo3IDqdwv8AWHI/H4ddPOkcnU6X1tyHCdzsvEdZRptxtlb8S6H4X85S0frWk/jaJiMcRMq0IyJjMRhBQiJjhLYhCEBwhCASj6WVstJE+29z3hRf4lZeTkel1a9Wmn2aZPmx/JRJr6rbxSJrJ2mGg2pHL+/nNkTRjKASSCyQkqaZmVRvYgDlcmD1jZRAAhVNjroDY2J0vYzrcNhwqClkU2Ha00bv75pbW2Wz0qdNWH0L56bWAVjZhla264Y6+B7phGaJnx0/5ZiN7USSUxo/1WUqw3q2jAyd5vEuWY0kTIs8i7zA1SDTBtOoerqW35SPWa2GOdrfVFh4omg9WBPlHtAk02ANj2QDyOYWktnqAuYbj7P4F0X3CR+rfjfBnR9Fa91qU+RDjz0PwX1nNIdPEyz6PVsmIUcHDJ7rj3gRbwryXYxEx3kTM25EyJMZgYCJhEYQhtQjhISIo4pIc4PpPUviqn3ci+ig/nO8nne23zYiueVRx5A2+Umql/FWtfJUUn2X7B7m/v4CWatKeutxUU87g8u/1llSa4vLwylsXm5shqZqgVNxFk1sA9xb5yvzTPszGLSqh3UMtiraXIB4jv8AzMi/azpbHqLRMu1wyc9QNxm06jdwPCV2ExCkZkN1O4g3FpvJUuPlynA9TbnOlGzmNMVaYu9E5rD2mp2OZe/mPCc5QxQcAieiVALa7pwW2tgth2arQBakSWamNWTico4r3cPDdvhya5Lmz4vl/UMDvNapWA3m01nxugIsVPHjItU42JB5Tp249Fjan0dRuSkjy1+U3sInYRfurf0lTizem45ow9RLqkSABIgnxlI3SdGpkqI/2HVvQ3mNTrFU3yyIeh3vu8oiZq7Mq56NNuaKD4r2T7xNmZOgRGORMBGKBhCG7CEJCRCEIBPMsc+arWPOo59WJnponljNepU8fzlqqXa1c2ZeToVPiJsYLNYeAF+/jNPHX6vMN9Ns3lub3EyWx9oAt1TfWBameZ3lfn6y2+s9cWhmBxNl1mJ1lkJ4DaD0GBU3U+1TPsnvHI986eht+iMuaoELKD2rhQdeyzWsDpORVInXcO/5GZWx1s2pmtXjunxwIuCCp3Eaj1Egj/3ecXTrPR1pmw3lLnK35ToNm49a63Q2ZdHQ2zIfmORnLkxTV2Ys1b88lDanR6nXzGnam7amw7DNzK8+8TjcdgK+FuKiELewcXam3g3DznoqNMujAhgGB0IOokVy2r71N8NbeceU4irdH71MvsNUzIrcGVWHmLy62n0Ro1STTJoseCWyf6Tp6WlNRwL4T6GqGYIBkempYOnDQXI/vWdWPLW06ceXDNI3LYpxVN8wLj6ZJHWIpG9XOQj1mXODy/ObMHXdGqmahb7DsPI2PzlrKPoo3YqDkyn1B/KXhMzn1tHgMiYyZAmQsDCRMIG9HFCQCEIQEx0PgZ5QD9I45gH4T1asbI55K3wnk2IOWqh4MpXztLVUsA1735EGUezBbEUxwBfL4ZWlpnszr3k+RlfsdP2tVP1c58sp/OJ9RHkuqUxNJgRMJozYXNoEbvH5GDb/ADE28U1Mil1aOrKtqpZi2d7G5Gug9OGmlzCWlW3iaT5qb9ZTYow3MPgeY7pvVRrNbHpmQ2375ExsrOl/sfba17JUslbgNyVPw9/d8ZbpUIOs80R8w5EeoM6HYvSQEihiTY3CpVOgY8Fc8DyPHx38uTF+w7sWbfLOwWrKrbTjNTPNWHoR+Zmzrw1HvlZtY9lWP1SR6/8AIEpi5eGmaPlSVbjERrXAza2I3i80xUI0IF1FyBp2bkXHLdMdevcixkazWOf+GLnvW12Hv907dvNiHZ9D6mZKpF96b9/150ZM5roWtkrEbi6W8LE/OdITKz61jwiZEmMmRMhYiYRGECwhCEgEIQgY8SwFOoToAjk9wAM8oxfaUEA3U3FwReen7Ya2HrW/huPUWnndUaar75arO3qixZIIqId4s3Hw+czbDGauXO8I9+HFZPEBLMPZub6lgL915Do+o6ypYk3pqTrcXuBp6Sf1H46C8i0YiaXUY8syON3j8jI3knN7ePyMDFUkWFwZN5GQlz9ZclQ8jNXEJmvLXalLjK2UmGkSsdjdI6lK1OoS6DRWPtoOX3hLfaO1usouQrZd2fQqDpfUX5zjnWxnqf6P1tggft1ahPuX+mU+Nd7afO2vjt59QqXIPDn3TM+K3jQA3uBx7ieU9Px+xMPXv1lFMzWu6jI9xuOYa+spafQmgtQOalV0Bv1bZO13MwGo8APGW2p8W70RwppYSncWL/SAHeEsAvuAPnLkmERhYjEYGRJgImORJigWkIQkAhCEDS20f2er+ED/ANhOArT0HatMvRqKtrlbi5sNCCfhOPqbHrWuEU+Drf32kxatfZVtS1uxG3N4nQEzH0eN6lU8kQX7rn8pLbNN0OUow5klTf0M3tlbJehTStUKj9ZGami3JFNbdpuV827ukxaJnis1mI7DeaY2k2EgZozRM2cZiQ4pgU0p9WgQmmti5APaY8T+Z7gNRmknci17b/kYSTCQjLXiga2MS6yldLEzoaguJUYmlKymsqx1uZ6n0F/wNP8AHW/3tPNertPSOgzfsaj7NSoPU3+cq0h0RkTGTIkyFiMiTAyJMBEyJjJiJgIwiMIFreEIoDvC8UJAxYn2H/CZpronlNzE+w/4TK+s1qflObN9odOD6y4nbCGtiUorvqOqeFza/kPhL3pFZalOmuiUqaoo5Dl6ATV6PUes2g7kXFGmzfzt2R7i0Nq1c9eo3DOVHgtl+U3wxxz557ppGQaSaRM6HMgVkalMjKcrgNfKSpVW4GxO+NzYE90lWrsyqha6IewNOzcgmQljtFHeLNJCfdNSsk2mmu4kSQ0XpTt+gb/QVU+zVzeTIv8A8mccdJ03QmrlqVaf20Vx4obf1ykr1nrsTImSMiZDREmRMZkTARMiTG0gTACYSBMIFzCEUBwhCQMOK/dv+E/CVO0Hy0/KW2K/dt4W9dJQdJHy0TbfY+6c+b7Q6cP1li6F08tPE4g/XcgH7qA/Nj6SnLX15/GdFsyn1ezF5th2c+NQFv6pzZnVjjUOPLO5RaQMbGQJmjJirG4tz3ybk8e6RfdERx7PDXjCQyxWmVYFLwMTTC0zVBYTGTIGu41m9sPFCniaTc3FM+D9n5g+U0akWFpM9SmiWzu4FO5A7W8fD3SJTD1MyBkr85EyjZEmImBkTARMgZImQMCJhETCBdXheKKQJQvFCBhxR7B8V+IlNt3DF6TKN5UgS5xJ0tzI/OauJXTWc+X7OrD9WrVqKNnqb2UUKSG+lj2UI9dJyrm0y9IMZlwmKoHjVw5TwcszD1p3/mM5XC7YdAFa1RRoLmzAdxnRS3HHkpO3QFpGaFPbFFvazoe9cw9VvNldoUf41MeJy/Ga7hlqY/E3gbd1/AXmJ9oUQL9dS8nWYP8AqFH+NSAuN2hOsbg1LfkWaa3/AFKgP89P9QmJ9rYcf5oP4VdvgI3BqWy5vIWlbX6QUxfIjueBNkX8/dK3EbYqvopCLrogufNj8rSs2haKyucZikQdptbXCjVj4CY+ipbEbQw5JsEc1AL7gilrDvNgDObsd+88STcmdT+jwftq/wDaq/0ys22vWunqhkTGZEwsRMgZIyJgQMiZIyBgIwiMIF1FeKEgOEIpIxVjqo75V4rG2xFOmdzhgNfrWuPgfdN3H6FD3n5TSofv6h4/q+/+YTmv22nXi5Tbg+mQYVyCdLLp36+v/M5pxOl6an9p/kX5zm2mtfrDDJ9pYCJAzOZjMsoxmK2kkYLAiEsNZG0ytviEILLHaMwMJKdR+j3XG+FCqfHVB85y5nVfo5/xjf8AjVP99OSPTjImMyJkoIyJjMgYCMgRJSMBGEDCB//Z',
        name: 'Premium Shirt',
        price: '$999',
        color: 'orange',
        href: '#',
        breadcrumbs: [
          { id: 3, name: 'Men', href: '#' },
          { id: 4, name: 'Outerwear', href: '#' },
        ],
        images: [
          {
            src: 'https://muselot.in/cdn/shop/products/3_f0aee5ac-6678-4613-8f02-c5d5820dd010.jpg?v=1625002577&width=1445',
            alt: 'Front view of a premium black hoodie.',
          },
          {
            src: 'https://media.gettyimages.com/id/109433981/photo/boy-wearing-orange-t-shirt-playing-with-toy-plane.jpg?s=612x612&w=0&k=20&c=hOKHrutzEgEAiSKo8PAg8X5ZSnEYzzk1Kzewz_aWbr0=',
            alt: 'Model wearing the premium hoodie with a cap.',
          },
          {
            src: 'https://media.gettyimages.com/id/109433981/photo/boy-wearing-orange-t-shirt-playing-with-toy-plane.jpg?s=612x612&w=0&k=20&c=hOKHrutzEgEAiSKo8PAg8X5ZSnEYzzk1Kzewz_aWbr0=',
            alt: 'Model wearing the premium hoodie with a backpack.',
          },
          {
            src: 'https://5.imimg.com/data5/SELLER/Default/2021/5/ES/XP/FW/125037753/orange-t-shirt.jpg',
            alt: 'Close-up of the premium hoodie fabric texture.',
          },
        ],
        colors: [
          { name: 'Orange', class: 'bg-orange-600', selectedClass: 'ring-orange-800' },
        ],
        sizes: [
          { name: 'XS', inStock: true },
          { name: 'S', inStock: true },
          { name: 'M', inStock: true },
          { name: 'L', inStock: true },
          { name: 'XL', inStock: true },
        ],
        description:
          'Stay warm and stylish with our Premium Shirt. Made from high-quality materials, this Shirt is perfect for any casual occasion. Choose from classic black, charcoal gray, or navy blue to suit your style.',
        highlights: [
          'Premium quality fabric',
          'Versatile and comfortable fit',
          'Ideal for layering',
          'Available in multiple colors',
        ],
        details:
          'The Premium Shirt is a must-have for your wardrobe. Whether you\'re heading out for a run or just lounging at home, this hoodie will keep you comfortable and looking great.',
      },
      {
        id: 5,
        imageSrc: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUREhISEhEREhEREhERERERERERERERGBgZGRgYGBgcIS4lHB4rIRgZJjgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHhISGjEhJCQ0NDQ0NjE0NDE0NDE0MTQ0NDQ0NDE0NDQ0NDExNDQ0NDQxNDQ0MTQ0NDQxPTQ0NDQ0Mf/AABEIAPsAyAMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAAAQIFAwQGBwj/xABCEAACAQIDBAcEBggFBQAAAAABAgADEQQSIQUxQVEGEyJhcYGRMqGxwSNCUmJy0QcUJDNTgsLwNEOSsuEVc3Si0v/EABkBAQADAQEAAAAAAAAAAAAAAAABAgMEBf/EAB8RAQACAwEAAwEBAAAAAAAAAAABAgMRITESMkEiFP/aAAwDAQACEQMRAD8A7GEIpYEcIQCEIQg5q4/aFPDp1lV1ppewJ3k8gBqT3CZcTiEpo1So6pTQXZ2NlUTyjbm0Tjq71czfq6HLRVrqAg45eZ3nju5SszpasbXeP6aVapdMOqUqe4VHOatb7WXcPfKStjarD6TEVKi33s7kA94ubek0lrhRYKrDd7TK3xtIDErwLXGhRzdh4GZzMy0iIhY4Ta74Z81NyM2hBN0qd3j42M7vo90mp4tVUkJW3MhNgT93xGtu4zyHGVSTYa9/np/fjMFKuyMrBrMpDKRvDcDLV4raYl9Cwlb0e2oMXh6dYaEjK63vlddGHz85ZTRQQhCEHCKEAgRCEBESJk4jAxkSJEmZEwImECIQM0cIQkQhCAQhCBxv6RcQ3V0aIHYqO1So33Uy2HmW904DEvlAUA6DhoPQTvOn9B6j4UItwS65j7IdimUE8L/Kc/0a6PfrFep1wISi2Wom4l/sn0mVp12WlY3yFNs7Y9bFH6KmTY2L6KB58Z0GH6BYhnBqMgFhchiZ6hgMElJAqKFUDQKLCSqLrpMpvLaKQ852l0N6lDUWxtYW+M4zEbJdTu1v6z3TE0c6lWGhnK7Y2UqDPvW9mBA0vukxZFqRLR/Ri5VMRSOlmSoB3sCp/wBqzupyWwcA1B2rr2g9PKKY0JXMCWJ5iwt+Izq0YEAjcQCPAzatoljak17KUIQl2YhCEAhFCA4jCECJkTJyJgQMIyIQMsIQhIjhCAoRwgQdAwswBB4ESuGEShUrVswVKvVs+YgBaiggtfvFvMGWk1do4RKyFKihluGAYXFxqLjjKWruq9Lats8BtjDv2UrJUYcEYGU3Szb9akMmHQLcXaq3aynkq8T46SvwnRx1qrUD9WQxJFMKqEX04ct/ynV4jCI6qWAuLHcN4nPzfHTEb9cTs2piHcK/62zqRmZ6hVCTyUMAfQzs+qvTy1NQRYg6zNQwqL2lAvz3mY8Q/CRM7TEahUU0cdT1bkCmz03Qi6MgJsTyNh75d0FsoA3AWHhwlNgFzvruFRiedmAtr5GXoFprir2ZZZrbiIEIQm7mEUdooBCEIBFHFCRFHFCCIhHCEpRwhAIQhAIQhAIQhA19xI9PCaG1tsrh16sAF7aZibdx0m9jUNg66su9RvZOIHeN49OMoHwpdmcuhtrmCB3C7xYNoPQzmtX42dmO3yjX62sJtlVp3qEhmJbQEIoPCZ8ZiPo7g+0ND/xKvBlKhYFHfIbs1Y5jccbHQeQErtpbUZcyncXso5cgJTXVrTELLZFe9VgDupqfMMSJ1QN5yXR6h1a5mFnfVuNhwHwld0m25jsLiUp0mTqa2UU2NJXKtuZSTy9rw8JtS3dOe8fzt30JW7F2j19PtfvEsH4X5N5/EGWU2YR0QheEJKEcRhAijihIiheKECEV4QMsIQhIhCEAhCOAoQg7AAkkAAXJOgA5kwCc3tzD9TVp1qV81UsHpj65AvmUc+7jw13y2l0nRLrRXrG3ZyDkB7vte6cvicbVrNeo7k3uljYJxBUDRTcDXuia/KNIi/xncNjFbXYZ+y5uNbU2Av3m2+amApGo2d/qfu0OuXvPfLnAbVWugSqVDgtTz2+jqFdD4NpqPSb36mEDObBFBY23ZQLkzmncc06omLRvaOCfIt2IAA1MqNqY7rmFh2V9m41PfKqtt81KnVsopow7ABJ1vuc85lL218vE902x49dlz5cu/wCY8WOzdoNh3zque4yst7Aqbce6wnT4XpBTfRw1M/eGZf8AUPmJx2GoEEs3tMAD3AXsPfNm2k3mu3PFph3tN1cZlZWU7ipBHrJThsNXembo5U93HxG4y+we3QdKq5T9tNV8xvHleUmstIvEruKRRwwDKQVOoINwZKQsURjihJRQMUAhFCEM8I4oSIQjgEITDjMQKVN6h3IpNuZ4DzNh5wNTau1kwy9rtVGF0pg6nvJ4DvnH4/aNTEH6Ruxe4RdKY8uJ7zMNd2qOzuczsbk/3wkGWXiumNrbYzIVAbXG8XtM2WMLLKqXBUK/UmjUbsBmdR9YOxuWvw1F5bNtlxhGwxR3quMgOlurPtG/hcecy2k0pUjTYlX68sMrBrJ1dt3O9/lrvBzmkTpeuS0bVeC2Rft1NWPAblHKW1Ogq20vbcTqZNBYW4CSmkQpM7ShEIxCBMYqb+4284V6gRWb7Kk+gvK7C1LIlzqwLufu3v7z8IIdFsnaDU3UZvo3IDqdwv8AWHI/H4ddPOkcnU6X1tyHCdzsvEdZRptxtlb8S6H4X85S0frWk/jaJiMcRMq0IyJjMRhBQiJjhLYhCEBwhCASj6WVstJE+29z3hRf4lZeTkel1a9Wmn2aZPmx/JRJr6rbxSJrJ2mGg2pHL+/nNkTRjKASSCyQkqaZmVRvYgDlcmD1jZRAAhVNjroDY2J0vYzrcNhwqClkU2Ha00bv75pbW2Wz0qdNWH0L56bWAVjZhla264Y6+B7phGaJnx0/5ZiN7USSUxo/1WUqw3q2jAyd5vEuWY0kTIs8i7zA1SDTBtOoerqW35SPWa2GOdrfVFh4omg9WBPlHtAk02ANj2QDyOYWktnqAuYbj7P4F0X3CR+rfjfBnR9Fa91qU+RDjz0PwX1nNIdPEyz6PVsmIUcHDJ7rj3gRbwryXYxEx3kTM25EyJMZgYCJhEYQhtQjhISIo4pIc4PpPUviqn3ci+ig/nO8nne23zYiueVRx5A2+Umql/FWtfJUUn2X7B7m/v4CWatKeutxUU87g8u/1llSa4vLwylsXm5shqZqgVNxFk1sA9xb5yvzTPszGLSqh3UMtiraXIB4jv8AzMi/azpbHqLRMu1wyc9QNxm06jdwPCV2ExCkZkN1O4g3FpvJUuPlynA9TbnOlGzmNMVaYu9E5rD2mp2OZe/mPCc5QxQcAieiVALa7pwW2tgth2arQBakSWamNWTico4r3cPDdvhya5Lmz4vl/UMDvNapWA3m01nxugIsVPHjItU42JB5Tp249Fjan0dRuSkjy1+U3sInYRfurf0lTizem45ow9RLqkSABIgnxlI3SdGpkqI/2HVvQ3mNTrFU3yyIeh3vu8oiZq7Mq56NNuaKD4r2T7xNmZOgRGORMBGKBhCG7CEJCRCEIBPMsc+arWPOo59WJnponljNepU8fzlqqXa1c2ZeToVPiJsYLNYeAF+/jNPHX6vMN9Ns3lub3EyWx9oAt1TfWBameZ3lfn6y2+s9cWhmBxNl1mJ1lkJ4DaD0GBU3U+1TPsnvHI986eht+iMuaoELKD2rhQdeyzWsDpORVInXcO/5GZWx1s2pmtXjunxwIuCCp3Eaj1Egj/3ecXTrPR1pmw3lLnK35ToNm49a63Q2ZdHQ2zIfmORnLkxTV2Ys1b88lDanR6nXzGnam7amw7DNzK8+8TjcdgK+FuKiELewcXam3g3DznoqNMujAhgGB0IOokVy2r71N8NbeceU4irdH71MvsNUzIrcGVWHmLy62n0Ro1STTJoseCWyf6Tp6WlNRwL4T6GqGYIBkempYOnDQXI/vWdWPLW06ceXDNI3LYpxVN8wLj6ZJHWIpG9XOQj1mXODy/ObMHXdGqmahb7DsPI2PzlrKPoo3YqDkyn1B/KXhMzn1tHgMiYyZAmQsDCRMIG9HFCQCEIQEx0PgZ5QD9I45gH4T1asbI55K3wnk2IOWqh4MpXztLVUsA1735EGUezBbEUxwBfL4ZWlpnszr3k+RlfsdP2tVP1c58sp/OJ9RHkuqUxNJgRMJozYXNoEbvH5GDb/ADE28U1Mil1aOrKtqpZi2d7G5Gug9OGmlzCWlW3iaT5qb9ZTYow3MPgeY7pvVRrNbHpmQ2375ExsrOl/sfba17JUslbgNyVPw9/d8ZbpUIOs80R8w5EeoM6HYvSQEihiTY3CpVOgY8Fc8DyPHx38uTF+w7sWbfLOwWrKrbTjNTPNWHoR+Zmzrw1HvlZtY9lWP1SR6/8AIEpi5eGmaPlSVbjERrXAza2I3i80xUI0IF1FyBp2bkXHLdMdevcixkazWOf+GLnvW12Hv907dvNiHZ9D6mZKpF96b9/150ZM5roWtkrEbi6W8LE/OdITKz61jwiZEmMmRMhYiYRGECwhCEgEIQgY8SwFOoToAjk9wAM8oxfaUEA3U3FwReen7Ya2HrW/huPUWnndUaar75arO3qixZIIqId4s3Hw+czbDGauXO8I9+HFZPEBLMPZub6lgL915Do+o6ypYk3pqTrcXuBp6Sf1H46C8i0YiaXUY8syON3j8jI3knN7ePyMDFUkWFwZN5GQlz9ZclQ8jNXEJmvLXalLjK2UmGkSsdjdI6lK1OoS6DRWPtoOX3hLfaO1usouQrZd2fQqDpfUX5zjnWxnqf6P1tggft1ahPuX+mU+Nd7afO2vjt59QqXIPDn3TM+K3jQA3uBx7ieU9Px+xMPXv1lFMzWu6jI9xuOYa+spafQmgtQOalV0Bv1bZO13MwGo8APGW2p8W70RwppYSncWL/SAHeEsAvuAPnLkmERhYjEYGRJgImORJigWkIQkAhCEDS20f2er+ED/ANhOArT0HatMvRqKtrlbi5sNCCfhOPqbHrWuEU+Drf32kxatfZVtS1uxG3N4nQEzH0eN6lU8kQX7rn8pLbNN0OUow5klTf0M3tlbJehTStUKj9ZGami3JFNbdpuV827ukxaJnis1mI7DeaY2k2EgZozRM2cZiQ4pgU0p9WgQmmti5APaY8T+Z7gNRmknci17b/kYSTCQjLXiga2MS6yldLEzoaguJUYmlKymsqx1uZ6n0F/wNP8AHW/3tPNertPSOgzfsaj7NSoPU3+cq0h0RkTGTIkyFiMiTAyJMBEyJjJiJgIwiMIFreEIoDvC8UJAxYn2H/CZpronlNzE+w/4TK+s1qflObN9odOD6y4nbCGtiUorvqOqeFza/kPhL3pFZalOmuiUqaoo5Dl6ATV6PUes2g7kXFGmzfzt2R7i0Nq1c9eo3DOVHgtl+U3wxxz557ppGQaSaRM6HMgVkalMjKcrgNfKSpVW4GxO+NzYE90lWrsyqha6IewNOzcgmQljtFHeLNJCfdNSsk2mmu4kSQ0XpTt+gb/QVU+zVzeTIv8A8mccdJ03QmrlqVaf20Vx4obf1ykr1nrsTImSMiZDREmRMZkTARMiTG0gTACYSBMIFzCEUBwhCQMOK/dv+E/CVO0Hy0/KW2K/dt4W9dJQdJHy0TbfY+6c+b7Q6cP1li6F08tPE4g/XcgH7qA/Nj6SnLX15/GdFsyn1ezF5th2c+NQFv6pzZnVjjUOPLO5RaQMbGQJmjJirG4tz3ybk8e6RfdERx7PDXjCQyxWmVYFLwMTTC0zVBYTGTIGu41m9sPFCniaTc3FM+D9n5g+U0akWFpM9SmiWzu4FO5A7W8fD3SJTD1MyBkr85EyjZEmImBkTARMgZImQMCJhETCBdXheKKQJQvFCBhxR7B8V+IlNt3DF6TKN5UgS5xJ0tzI/OauJXTWc+X7OrD9WrVqKNnqb2UUKSG+lj2UI9dJyrm0y9IMZlwmKoHjVw5TwcszD1p3/mM5XC7YdAFa1RRoLmzAdxnRS3HHkpO3QFpGaFPbFFvazoe9cw9VvNldoUf41MeJy/Ga7hlqY/E3gbd1/AXmJ9oUQL9dS8nWYP8AqFH+NSAuN2hOsbg1LfkWaa3/AFKgP89P9QmJ9rYcf5oP4VdvgI3BqWy5vIWlbX6QUxfIjueBNkX8/dK3EbYqvopCLrogufNj8rSs2haKyucZikQdptbXCjVj4CY+ipbEbQw5JsEc1AL7gilrDvNgDObsd+88STcmdT+jwftq/wDaq/0ys22vWunqhkTGZEwsRMgZIyJgQMiZIyBgIwiMIF1FeKEgOEIpIxVjqo75V4rG2xFOmdzhgNfrWuPgfdN3H6FD3n5TSofv6h4/q+/+YTmv22nXi5Tbg+mQYVyCdLLp36+v/M5pxOl6an9p/kX5zm2mtfrDDJ9pYCJAzOZjMsoxmK2kkYLAiEsNZG0ytviEILLHaMwMJKdR+j3XG+FCqfHVB85y5nVfo5/xjf8AjVP99OSPTjImMyJkoIyJjMgYCMgRJSMBGEDCB//Z',
        name: 'Premium Black Shirt',
        price: '$1999',
        color: 'orange',
        href: '#',
        breadcrumbs: [
          { id: 3, name: 'Men', href: '#' },
          { id: 4, name: 'Outerwear', href: '#' },
        ],
        images: [
          {
            src: 'https://muselot.in/cdn/shop/products/3_f0aee5ac-6678-4613-8f02-c5d5820dd010.jpg?v=1625002577&width=1445',
            alt: 'Front view of a premium black hoodie.',
          },
          {
            src: 'https://media.gettyimages.com/id/109433981/photo/boy-wearing-orange-t-shirt-playing-with-toy-plane.jpg?s=612x612&w=0&k=20&c=hOKHrutzEgEAiSKo8PAg8X5ZSnEYzzk1Kzewz_aWbr0=',
            alt: 'Model wearing the premium hoodie with a cap.',
          },
          {
            src: 'https://media.gettyimages.com/id/109433981/photo/boy-wearing-orange-t-shirt-playing-with-toy-plane.jpg?s=612x612&w=0&k=20&c=hOKHrutzEgEAiSKo8PAg8X5ZSnEYzzk1Kzewz_aWbr0=',
            alt: 'Model wearing the premium hoodie with a backpack.',
          },
          {
            src: 'https://5.imimg.com/data5/SELLER/Default/2021/5/ES/XP/FW/125037753/orange-t-shirt.jpg',
            alt: 'Close-up of the premium hoodie fabric texture.',
          },
        ],
        colors: [
          { name: 'Orange', class: 'bg-orange-600', selectedClass: 'ring-orange-800' },
        ],
        sizes: [
          { name: 'XS', inStock: true },
          { name: 'S', inStock: true },
          { name: 'M', inStock: true },
          { name: 'L', inStock: true },
          { name: 'XL', inStock: true },
        ],
        description:
          'Stay warm and stylish with our Premium Black Shirt. Made from high-quality materials, this Black Shirt is perfect for any casual occasion. Choose from classic black, charcoal gray, or navy blue to suit your style.',
        highlights: [
          'Premium quality fabric',
          'Versatile and comfortable fit',
          'Ideal for layering',
          'Available in multiple colors',
        ],
        details:
          'The Premium Black Shirt is a must-have for your wardrobe. Whether you\'re heading out for a run or just lounging at home, this hoodie will keep you comfortable and looking great.',
      },
  ]);

  return (
    <ProductContext.Provider value={{ products, setProducts }}>
      {children}
    </ProductContext.Provider>
  );
};

export const useProductContext = () => {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error('useProductContext must be used within a ProductProvider');
  }
  return context;
};
