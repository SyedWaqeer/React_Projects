import React from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { name_validation, password_validation, num_validation, email_validation, desc_validation, sel_validation } from '../utils/inputValidations';
import { useState } from 'react';
import Input from '../components/Inputs';
import { Link } from 'react-router-dom';

export default function Signup(props) {
  const methods = useForm();
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const onSubmit = methods.handleSubmit(async (data) => {
    try {
      const existingUserResponse = await fetch('https://6583de2a4d1ee97c6bce6c48.mockapi.io/6025/users');
      const existingUsers = await existingUserResponse.json();

      const userExists = existingUsers.some(existingUser => existingUser.email === data.Email);

      if (userExists) {
        setError('User with this email already exists');
        return;
      }

      const response = await fetch('https://6583de2a4d1ee97c6bce6c48.mockapi.io/6025/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        console.log('User registered successfully');
        setSuccess(true);
      } else {
        console.error('Error registering user:', response.status, response.statusText);
        setError('Error registering user');
      }
    } catch (error) {

      console.error('Error registering user:', error);
      setError('Network error');
    }
  });

  return (
    <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
      <div className=" sm:mx-auto sm:w-full sm:max-w-sm">
        <h2 className="mt-10 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">
          {!success ? 'Create an account to Sign up' : 'Sign up successful!'}
        </h2>
      </div>

      

      <div className=" sm:mx-auto sm:w-full sm:max-w-sm">
        {!success ? (
          <FormProvider {...methods}>
            <form
              className="space-y-6"
              action="#"
              method="POST"
              noValidate
              autoComplete="off"
              onSubmit={onSubmit}
            >
              <div className="mt-2">
                <Input {...email_validation} />
              </div>
              <div className="mt-2">
                <Input {...name_validation} />
              </div>
              <div className="mt-2">
                <Input {...num_validation} />
              </div>
              <div className="mt-2">
                <Input {...password_validation} />
              </div>
              <div>
                <button
                  type="submit"
                  className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                >
                  Sign up
                </button>
              </div>
            </form>
          </FormProvider>
        ) : (
          <div className="mt-3 text-center">
            <p className="text-green-500 ">Registration successful!</p>
            <Link to='/signin' className="font-semibold mt-14 mb-4 leading-6 text-indigo-600 hover:text-indigo-500">
              Login
            </Link>
          </div>
        )}
        {error && (
          <p className="mt-3 text-center text-red-500">{error}</p>
        )}
        {!success && (
          <p className="mt-10 text-center text-sm text-gray-500">
            already have an account?{' '}
            <Link to='/signin' className="font-semibold leading-6 text-indigo-600 mt-8 hover:text-indigo-500">
              Sign in
            </Link>
          </p>
        )}
      </div>
    </div>
  );
}
