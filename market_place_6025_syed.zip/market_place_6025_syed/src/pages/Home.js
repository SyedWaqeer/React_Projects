import React from 'react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div className="w-screen h-screen text-white" style={{
      background: "linear-gradient(90deg, rgba(131, 126, 226, 1) 24%, rgba(114, 114, 226, 1) 58%, rgba(0, 212, 255, 1) 100%)"
    }}>
      <div class="container mx-auto flex px-5 py-24 items-center justify-center flex-col">
        <div class="text-center pt-12 mt-12  w-full">
          <h1 className="my-4 text-5xl  font-bold italic leading-tight">
          Elevate Your Style with FashionInsta: Where Trends Meet Timeless Elegance!
          </h1>
          <p className="text-2xl italic mb-8">
          Explore the Latest Trends, Elevate Your Look, and Be Unapologetically You.
          </p>
          <div className="flex justify-center mx-auto">
            <Link
            to="/services"
              className="hover:underline bg-white text-gray-800 font-bold rounded-full  py-4 px-8">
              View Products
            </Link>
            
          </div>
        </div>
      </div>
    </div >
  );
}
