import React from 'react';
import { useCartContext } from '../data/CartContext';
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom';


const Cart = () => {
  const { cart, clearCart, removeFromCart } = useCartContext();
  const Navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const total = cart.map((product) => {
    const price = parseFloat(product.price.replace('$', ''));
    return price;
  });
  const TotalSum = total.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
  const handleCheckout = async () => {
    setLoading(true);

    const checkoutData = cart.map((product) => ({
      name: product.name,
      color: product.color,
      price: product.price,
    }));

    try {
      // Make a POST request to the API
      const response = await fetch('https://6583de2a4d1ee97c6bce6c48.mockapi.io/6025/CheckoutDetails', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(checkoutData),
      });

      if (response.ok) {
        alert('Thank you for shopping!');
        clearCart();
        Navigate('/services');
      } else {
        console.error('Error during checkout:', response.status, response.statusText);
        alert('Checkout failed. Please try again.');
      }
    } catch (error) {
      console.error('Error during checkout:', error.message);
      alert('Checkout failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveItem = (productId) => {
    removeFromCart(productId);
  };
  return (
    <div className="flex h-full  mb-14 flex-col overflow-y-scroll content-center bg-white shadow-xl max-w-2xl mx-auto">
      <div className="flex-1 mt-14 p-14 overflow-y-auto px-4 py-6 sm:px-6">
        <div className="mt-10">
          <div className="flow-root">
            <ul role="list" className="-my-6 divide-y divide-gray-200">
              {cart.map((product) => (
                <li key={product.id} className="flex py-6">
                  <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border border-gray-200">
                    <img
                      src={product.imageSrc}
                      alt={product.imageAlt}
                      className="h-full w-full object-cover object-center"
                    />
                  </div>

                  <div className="ml-4 flex flex-1 flex-col">
                    <div>
                      <div className="flex justify-between text-base font-medium text-gray-900">
                        <h3>
                          <a href={product.href}>{product.name}</a>
                        </h3>
                        <p className="ml-4">{product.price}</p>
                      </div>
                      <p className="mt-1 text-sm text-gray-500">{product.color}</p>
                    </div>
                    <div className="flex flex-1 items-end justify-between text-sm">


                      <div className="flex">
                        <button
                          type="button"
                          className="font-medium text-indigo-600 hover:text-indigo-500"
                          onClick={() => handleRemoveItem(product.id)}
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="border-t mb-14 border-gray-200 px-4 py-6 sm:px-6">
        <div className="flex justify-between text-base font-medium text-gray-900">
          <p>Subtotal</p>
          <p>${TotalSum}</p>
        </div>
        <p className="mt-0.5 text-sm text-gray-500">Shipping and taxes calculated at checkout.</p>
        <div className="mt-6">
          <a
            onClick={handleCheckout}
            href="#"
            className="flex items-center justify-center rounded-md border border-transparent bg-indigo-600 px-6 py-3 text-base font-medium text-white shadow-sm hover:bg-indigo-700"
          >
            Checkout
          </a>
        </div>
        <div className="mt-6 flex justify-center text-center text-sm text-gray-500">
          <p>
            or
            <Link to="/services"
              type="button"
              className="font-medium text-indigo-600 hover:text-indigo-500"

            >
              Continue Shopping
              <span aria-hidden="true"> &rarr;</span>
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
};

export default Cart;
