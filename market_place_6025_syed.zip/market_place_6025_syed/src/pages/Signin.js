import React, { useState } from 'react';
import { useAuth } from '../data/AuthContext';
import { useForm, FormProvider } from 'react-hook-form';
import { password_validation, email_validation } from '../utils/inputValidations';
import Input from '../components/Inputs';
import { Link, Navigate, useNavigate } from 'react-router-dom';

const Signin = () => {
  const methods = useForm();
  const [error, setError] = useState('');
  const { login } = useAuth();
  const Navigate = useNavigate();

  const onSubmit = methods.handleSubmit(async (data) => {
    try {
      const response = await fetch('https://6583de2a4d1ee97c6bce6c48.mockapi.io/6025/users');
      const users = await response.json();

      const user = users.find((u) => u.Email === data.Email && u.Password === data.Password);

      if (user) {
        login(user);
        console.log('Login successful');
        Navigate('/services');
      } else {
        setError('Invalid email or password');
      }
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  });

  return (
    <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-sm">
        <h2 className="mt-10 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">
          Login to your account
        </h2>
      </div>
      <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
        <FormProvider {...methods}>
          <form
            className="space-y-6"
            action="#"
            method="POST"
            noValidate
            autoComplete="off"
            onSubmit={onSubmit}
          >
            <div className="mt-2">
              <Input {...email_validation} />
            </div>
            <div className="mt-2">
              <Input {...password_validation} />
            </div>
            <div>
              <button
                type="submit"
                className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              >
                Sign in
              </button>
            </div>
          </form>
        </FormProvider>
        {error && <p className="mt-3 text-center text-red-500">{error}</p>}
        <p className="mt-10 text-center text-sm text-gray-500">
          Don't have an Account?{' '}
          <Link to="/signup" className="font-semibold leading-6 text-indigo-600 hover:text-indigo-500">
            sign up
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Signin;
