import React from 'react';
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white p-8 flex flex-wrap justify-between">
      <div className="mb-4">
        <div className="flex items-center text-orange-500 text-2xl italic font-bold mb-2">
          Fashioninsta
        </div>
        <p className="text-sm mb-4">Elevate Your Style with FashionInsta: Where Trends Meet Timeless Elegance!</p>
        <div className="flex space-x-4">
          <a href="#" className="text-white hover:text-gray-500">
            <FaFacebook />
          </a>
          <a href="#" className="text-white hover:text-gray-500">
            <FaTwitter />
          </a>
          <a href="#" className="text-white hover:text-gray-500">
            <FaInstagram />
          </a>
          <a href="#" className="text-white hover:text-gray-500">
            <FaLinkedin />
          </a>
        </div>
        <div className="text-xs mt-4">
          <p>&copy; 2023 Your Company. All rights reserved.</p>
        </div>
      </div>
      <div className="mb-4">
        <h2 className="text-lg font-bold mb-2">Products</h2>
        <ul className="list-none">
          <li><a href="#">Basic Tee 6 pack</a></li>
          <li><a href="#">White Tshirt</a></li>
        </ul>
      </div>
      <div className="mb-4">
        <h2 className="text-lg font-bold mb-2">Help</h2>
        <ul className="list-none">
          <li><a href="#">About Us</a></li>
          <li><a href="#">FAQs</a></li>
        </ul>
      </div>
      <div className="mb-4">
        <h2 className="text-lg font-bold mb-2">Get in Touch</h2>
        <p className="text-sm mb-2">Email: info@fashioninsta.com</p>
        <p className="text-sm">Phone: +1 (123) 456-7890</p>
      </div>
    </footer>
  );
};

export default Footer;

