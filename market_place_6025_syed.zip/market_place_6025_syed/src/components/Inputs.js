import React from 'react'
import { useFormContext } from 'react-hook-form';
import { findInputError, isFormInvalid } from '../utils';

export default function Input(props) {

  const {
    register,
    formState: { errors }
  } = useFormContext();

  const inputError = findInputError(errors, props.label);
  const isInvalid = isFormInvalid(inputError);

  return (
    <>
      <label htmlFor={props.id} className="block text-sm font-medium leading-6 text-gray-900">
        {props.label}
      </label>
      <div className="mt-2">
        <input
          id={props.id}
          type={props.type}
          className="block w-full p-2 rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
          placeholder={props.placeholder}
          {...register(props.label, props.validation)}
        />
      </div>
      {isInvalid && <InputError message={inputError.error.message} />}
    </>
  );
}

const InputError = ({ message }) => {
  return (
    <div className='text-orange-500'>
      {message}
    </div>
  )
}
