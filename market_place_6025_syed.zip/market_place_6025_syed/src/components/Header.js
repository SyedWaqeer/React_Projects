import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../data/AuthContext';
import { useCartContext } from '../data/CartContext';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';

export default function Header() {
  const { user, logout } = useAuth();
  const { cart } = useCartContext();

  return (
    <header className="bg-slate-50 text-black p-4 fixed w-full  z-10 shadow-md">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center text-orange-500 text-2xl italic font-bold">
          Fashioninsta
        </div>
        <nav className="flex space-x-4 items-center">
          <Link to="/#" className="hover:text-gray-300">
            Home
          </Link>
          <Link to="/services" className="hover:text-gray-300">
            Product
          </Link>

          {user ? (
            <>
              <Link to="/cart" className="hover:text-gray-300">
                Cart ({cart.length})
              </Link>
              <button onClick={logout} className="hover:text-gray-300">
                Logout
              </button>
              <span className="hover:text-gray-300 flex items-center">
                <FontAwesomeIcon icon={faUser} className="mr-1" />
                {user.Name}
              </span>
              
            </>
          ) : (
            <>
              <Link to="/signin" className="hover:text-gray-300">
                Sign In
              </Link>
              
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
