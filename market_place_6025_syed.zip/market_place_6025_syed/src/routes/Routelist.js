import React, { lazy } from 'react';
import { useRoutes } from 'react-router-dom';
import Home from '../pages/Home';
import Services from '../pages/Services';
import Signin from '../pages/Signin';
import Signup from '../pages/Signup';
import ProductDetails from '../pages/ProductDetails'; 
import Cart from '../pages/Cart';

const RouteList = (product) => {
  let element = useRoutes([
    { path: '/', element: <Home /> },
    { path: '/services', element: <Services /> },
    { path: '/signin', element: <Signin /> },
    { path: '/signup', element: <Signup /> },
    { path: '/product/:productId', element: <ProductDetails /> },
    { path: '/cart', element: <Cart /> },
  ]);

  return element;
};

export default RouteList;
