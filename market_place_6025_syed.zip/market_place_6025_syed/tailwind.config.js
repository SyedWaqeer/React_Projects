const defaultTheme = require('tailwindcss/defaultTheme')
 
module.exports = {
  content: [
    './src/**/*.{js,jsx,ts,tsx}', // Include React components
    './public/index.html',        // Include the HTML file
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};